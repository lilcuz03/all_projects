import React from "react";
import { useState } from "react";

function Grid({value, onGridClick}){
  
  return (<button className="grid" onClick={onGridClick}>{value}</button>
  );
}

  export default function Board() {
    const [player1IsNext,setplayer1IsNext] =useState(true);
    const [grid,setGrid]=useState(Array(9).fill(null));

    function handleClick(i) {
      if(grid[i]||calculateWinner(grid)){
        return;
      }
      const player2Grid = grid.slice();
     if (player1IsNext){
      player2Grid[i]= "X";
     }
     else {
      player2Grid[i]= "O";

     }
      setGrid(player2Grid);
      setplayer1IsNext(!player1IsNext);
    }
    const winner=calculateWinner(grid);
    let status;
    if(winner){
      status= 'welldone💯'+ ',' +'player' +winner+'.'+'you have won';
    }
    else{
      status = 'Next player:' +(player1IsNext ? 'player1':'player2');
    }
    return(
      <React.Fragment>
        <div className="status">{status}</div>
        <div class="board">
        <div className ="container">
          <Grid value={grid[0]} onGridClick={() =>handleClick(0)}/>
          <Grid value={grid[1]} onGridClick={() =>handleClick(1)}/>
          <Grid value={grid[2]} onGridClick={() =>handleClick(2)}/>
        </div>
        <div className ="container">
        <Grid value={grid[3]} onGridClick={() =>handleClick(3)}/>
        <Grid value={grid[4]} onGridClick={() =>handleClick(4)}/>
        <Grid value={grid[5]} onGridClick={() =>handleClick(5)}/>
        </div>
        <div className ="container">
        <Grid value={grid[6]} onGridClick={() =>handleClick(6)}/>
        <Grid value={grid[7]} onGridClick={() =>handleClick(7)}/>
        <Grid value={grid[8]} onGridClick={() =>handleClick(8)}/>
        </div>
        </div>
      </React.Fragment>
    );
    }

    function calculateWinner(grid){
      const lines=[
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6]
      ];
    
      for (let i =0; i<lines.length;i++){
        const [a,b,c] = lines[i];
        if (grid[a] && grid[a]===grid[b] && grid[a] ===grid[c]){
          return grid[a];
        }
      }
      return null;
    }
  
