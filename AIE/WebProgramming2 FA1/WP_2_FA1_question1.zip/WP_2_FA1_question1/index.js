let Lambor = document.querySelector('.logo-lamborghini');
Lambor.addEventListener('click',()=>{
window.open('lambor.html')
});

let Porche = document.querySelector('.logo-porche');
Porche.addEventListener('click',()=>{
    window.open('porche.html');
});

let Mclaren = document.querySelector('.logo-mclaren');
Mclaren.addEventListener('click',()=>{
    window.open('mclaren.html')
});

let Pangani = document.querySelector('.logo-pangani');
Pangani.addEventListener('click',()=>{
    window.open('pangani.html');
})

let Ferrari = document.querySelector('.logo-ferrari');
Ferrari.addEventListener('click',()=>{
    window.open('ferrari.html');
})

